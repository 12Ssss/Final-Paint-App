let r
let d1, d2, d3, d4, d5, d6, d7, dEraser, dClear
let a, b
let ellipse1
let BrushSize
function setup() {
  createCanvas(615,700);
  background(255);
  a = 0
  b = 1
  BrushSize = 20
}

function draw(){
  strokeWeight(1)
  stroke(0)
  // Create a Drawing Pen
  if(mouseIsPressed){
  fill(a)
  line(mouseX,mouseY,pmouseX,pmouseY)
  }
  
  // Create buttons
  fill('red')
  ellipse(25,25,50,50)
  fill('orange')
  ellipse(25,75,50,50)
  fill('yellow')
  ellipse(25,125,50,50)
  fill('green')
  ellipse(25,175,50,50)
  fill('blue')
  ellipse(25,225,50,50)
  fill('indigo')
  ellipse(25,275,50,50)
  fill('pink')
  ellipse(25,325,50,50)
  fill('black')
  ellipse(580,25,50,50)
  fill(255)
  textAlign(CENTER)
  text('Eraser',580,30)
  fill('black')
  ellipse(580,75,50,50)
  fill(255)
  textAlign(CENTER)
  text('Clear',580,80)
  
  // Compute distance & radius
  r = 50/2
  d1 = dist(mouseX,mouseY,25,25)
  d2 = dist(mouseX,mouseY,25,75)
  d3 = dist(mouseX,mouseY,25,125)
  d4 = dist(mouseX,mouseY,25,175)
  d5 = dist(mouseX,mouseY,25,225)
  d6 = dist(mouseX,mouseY,25,275)
  d7 = dist(mouseX,mouseY,25,325)
  dEraser = dist(mouseX,mouseY,580,25)
  dClear = dist(mouseX,mouseY,580,75)
  
  // Give logic (buttons)
  if(d1 < r && mouseIsPressed){
    a = 'red'
  }
  if(d2 < r && mouseIsPressed){
    a = 'orange'
  }
  if(d3 < r && mouseIsPressed){
    a = 'yellow'
  }
  if(d4 < r && mouseIsPressed){
    a = 'green'
  }
  if(d5 < r && mouseIsPressed){
    a = 'blue'
  }
  if(d6 < r && mouseIsPressed){
    a = 'indigo'
  }
  if(d7 < r && mouseIsPressed){
    a = 'pink'
  }
  if(dEraser < r && mouseIsPressed){
    a = 220
  }
  if(dClear < r && mouseIsPressed){
  background(255)  
  fill('red')
  ellipse(25,25,50,50)
  fill('orange')
  ellipse(25,75,50,50)
  fill('yellow')
  ellipse(25,125,50,50)
  fill('green')
  ellipse(25,175,50,50)
  fill('blue')
  ellipse(25,225,50,50)
  fill('indigo')
  ellipse(25,275,50,50)
  fill('pink')
  ellipse(25,325,50,50)
  fill('black')
  ellipse(580,25,50,50)
  fill(255)
  textAlign(CENTER)
  text('Eraser',580,30)
  fill('black')
  ellipse(580,75,50,50)
  fill(255)
  textAlign(CENTER)
  text('Clear',580,80)
 }
// Give logic (thickness of Brush)
  function keyPressed() {
    if (keyCode === LEFT_ARROW && mouseIsPressed) {
      BrushSize = 5
    } else if (keyCode == RIGHT_ARROW && mouseIsPressed) {
      BrushSize = 10
    }
  }

  
  
  
  
  
  
  
  
  
  
  
}